<div class="sheetnode-phpexcel-export-download">
Your spreadsheet file <span class="filename"><?php print $filename ?></span> is <a class="download" href="<?php print $download ?>">ready for download</a> (will automatically start in 3 seconds.)
</div>
<div class="sheetnode-phpexcel-export-back">
You can also <a class="destination" href="<?php print $destination ?>">go back to your original page</a>.
</div>
