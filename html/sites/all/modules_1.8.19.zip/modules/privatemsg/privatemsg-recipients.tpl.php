<div class="privatemsg-message-participants">
  <?php print $participants; ?>
</div>