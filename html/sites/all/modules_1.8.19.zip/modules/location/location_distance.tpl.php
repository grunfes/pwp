<?php

/**
 * @file
 * Template for displaying distance.
 */
?>
<?php print number_format($distance, 2) . ' ' . $shortunit; ?>
