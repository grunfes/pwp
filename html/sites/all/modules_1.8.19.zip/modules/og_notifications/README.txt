Drupal module: Organic Groups Notifications
==========================================

This module integrates Notifications with Organic Groups.
User will be able to subscribe/unsubscribe on the all new nodes posted in a group and will be able to edit his subscriptions.

http://drupal.org/project/og_notifications
